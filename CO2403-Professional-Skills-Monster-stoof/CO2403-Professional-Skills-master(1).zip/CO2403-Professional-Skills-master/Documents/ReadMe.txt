This folder is to hold all documentation for the project
