// CBaseSprite.cpp 10-02-2018
// William John Atkin WJAtkin@UCLan.ac.uk

#include "BUILD_ORDER.h"

CBaseSprite::CBaseSprite() { }
